"use client";

import { DashboardOverview } from "@/features/dashboard/components/dashboard-overview";
import { DashboardShell } from "@/components/layout/dashboard-shell";
import { useDashboardScreenData } from "@/features/dashboard/hooks/use-dashboard";

export default function DashboardPage() {
  const { data, isFetching } = useDashboardScreenData();

  return (
    <DashboardShell
      user={data.user}
      sidebarItems={data.sidebarItems}
      workspaces={data.workspaces}
      activeWorkspaceId={data.activeWorkspaceId}
      notifications={data.notifications}
    >
      <DashboardOverview
        userName={data.user.name}
        learningPath={data.learningPath}
        courses={data.courses}
        upcomingExam={data.upcomingExam}
        streakDays={data.streakDays}
        rankPoints={data.rankPoints}
        rankLabel={data.rankLabel}
        suggestion={data.suggestion}
      />
      {isFetching ? (
        <p className="mt-4 px-1 text-xs font-medium text-slate-500 dark:text-slate-400">
          Data sync in progress...
        </p>
      ) : null}
    </DashboardShell>
  );
}
