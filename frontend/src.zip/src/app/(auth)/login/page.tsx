import Link from "next/link";
import { LockKeyhole, ShieldCheck } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { routes } from "@/lib/config/routes";

export default function LoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center px-6 py-14">
      <Card className="w-full max-w-md border-blue-100/90 bg-white/85 shadow-xl shadow-blue-100/50 backdrop-blur dark:border-slate-700 dark:bg-slate-900/80 dark:shadow-black/25">
        <CardHeader className="pb-2 text-center">
          <p className="mx-auto flex size-11 items-center justify-center rounded-2xl bg-blue-100 text-blue-600 dark:bg-slate-800 dark:text-sky-400">
            <LockKeyhole className="size-5" />
          </p>
          <CardTitle className="pt-2 text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-100">
            LearnOps Giriş
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-center">
          <p className="text-sm text-slate-600 dark:text-slate-300">
            OAuth akışı bağlanana kadar bu ekran UI placeholder olarak çalışır.
          </p>
          <Button className="h-10 w-full rounded-xl font-medium">
            <ShieldCheck className="size-4" />
            Provider ile Devam Et
          </Button>
          <Button
            asChild
            variant="outline"
            className="h-10 w-full rounded-xl border-blue-200 bg-white/80 font-medium text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
          >
            <Link href={routes.dashboard}>Dashboard Preview</Link>
          </Button>
        </CardContent>
      </Card>
    </main>
  );
}
