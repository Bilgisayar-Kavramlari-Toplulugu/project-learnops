import type {
  CourseCardItem,
  DashboardSuggestion,
  DashboardUser,
  LearningPath,
  NotificationItem,
  UpcomingExam,
  WorkspaceOption,
} from "@/types";
import { apiClient } from "@/lib/api/client";

export type CoursePayload = Omit<CourseCardItem, "icon" | "progressTone">;

export interface SuggestionPayload extends Omit<DashboardSuggestion, "icon"> {
  id?: string;
}

export interface DashboardStatsResponse {
  streakDays: number;
  rankPoints: number;
  rankLabel: string;
}

const dashboardEndpoints = {
  user: "/users/me",
  learningPath: "/learning-paths/active",
  courses: "/courses/enrolled",
  upcomingExam: "/exams/upcoming",
  stats: "/progress/stats",
  suggestion: "/courses/suggestions/next",
  workspaces: "/workspaces",
  notifications: "/notifications",
} as const;

export async function getDashboardUser() {
  const response = await apiClient.get<DashboardUser>(dashboardEndpoints.user);
  return response.data;
}

export async function getLearningPath() {
  const response = await apiClient.get<LearningPath>(dashboardEndpoints.learningPath);
  return response.data;
}

export async function getEnrolledCourses() {
  const response = await apiClient.get<CoursePayload[]>(dashboardEndpoints.courses);
  return response.data;
}

export async function getUpcomingExam() {
  const response = await apiClient.get<UpcomingExam>(dashboardEndpoints.upcomingExam);
  return response.data;
}

export async function getDashboardStats() {
  const response = await apiClient.get<DashboardStatsResponse>(dashboardEndpoints.stats);
  return response.data;
}

export async function getDashboardSuggestion() {
  const response = await apiClient.get<SuggestionPayload>(dashboardEndpoints.suggestion);
  return response.data;
}

export async function getWorkspaces() {
  const response = await apiClient.get<WorkspaceOption[]>(dashboardEndpoints.workspaces);
  return response.data;
}

export async function getNotifications() {
  const response = await apiClient.get<NotificationItem[]>(dashboardEndpoints.notifications);
  return response.data;
}

export async function markNotificationAsRead(notificationId: string) {
  await apiClient.patch(`${dashboardEndpoints.notifications}/${notificationId}/read`);
}

export async function markAllNotificationsAsRead() {
  await apiClient.patch(`${dashboardEndpoints.notifications}/read-all`);
}
