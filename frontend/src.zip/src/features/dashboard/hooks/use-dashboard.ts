"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { env } from "@/lib/config/env";
import { dashboardData } from "@/features/dashboard/mocks/dashboard.mock";
import { queryKeys } from "@/lib/api/query-keys";
import {
  getDashboardStats,
  getDashboardSuggestion,
  getDashboardUser,
  getEnrolledCourses,
  getLearningPath,
  getNotifications,
  getUpcomingExam,
  getWorkspaces,
  markAllNotificationsAsRead,
  markNotificationAsRead,
} from "@/features/dashboard/services/dashboard.service";
import type {
  CourseCardItem,
  DashboardSuggestion,
  NotificationItem,
  WorkspaceOption,
} from "@/types";

const USE_MOCK_DASHBOARD = env.nextPublicUseMockDashboard;

function mergeCoursesWithUiMeta(
  courses: Array<Omit<CourseCardItem, "icon" | "progressTone">>,
) {
  const fallbackById = new Map(
    dashboardData.courses.map((course) => [course.id, course]),
  );

  return courses.map((course) => {
    const fallbackCourse = fallbackById.get(course.id) ?? dashboardData.courses[0];

    return {
      ...fallbackCourse,
      ...course,
      icon: fallbackCourse.icon,
      progressTone: fallbackCourse.progressTone,
    };
  });
}

function mergeSuggestionWithUiMeta(
  suggestion: Omit<DashboardSuggestion, "icon">,
): DashboardSuggestion {
  return {
    ...dashboardData.suggestion,
    ...suggestion,
    icon: dashboardData.suggestion.icon,
  };
}

export function useDashboardScreenData() {
  const userQuery = useQuery({
    queryKey: queryKeys.dashboard.user(),
    queryFn: getDashboardUser,
    enabled: !USE_MOCK_DASHBOARD,
    initialData: dashboardData.user,
  });

  const learningPathQuery = useQuery({
    queryKey: queryKeys.dashboard.learningPath(),
    queryFn: getLearningPath,
    enabled: !USE_MOCK_DASHBOARD,
    initialData: dashboardData.learningPath,
  });

  const coursesQuery = useQuery({
    queryKey: queryKeys.dashboard.courses(),
    queryFn: getEnrolledCourses,
    enabled: !USE_MOCK_DASHBOARD,
    initialData: dashboardData.courses.map((course) => ({
      id: course.id,
      title: course.title,
      description: course.description,
      completedLessons: course.completedLessons,
      totalLessons: course.totalLessons,
      level: course.level,
      progress: course.progress,
    })),
  });

  const upcomingExamQuery = useQuery({
    queryKey: queryKeys.dashboard.upcomingExam(),
    queryFn: getUpcomingExam,
    enabled: !USE_MOCK_DASHBOARD,
    initialData: dashboardData.upcomingExam,
  });

  const statsQuery = useQuery({
    queryKey: queryKeys.dashboard.stats(),
    queryFn: getDashboardStats,
    enabled: !USE_MOCK_DASHBOARD,
    initialData: {
      streakDays: dashboardData.streakDays,
      rankPoints: dashboardData.rankPoints,
      rankLabel: dashboardData.rankLabel,
    },
  });

  const suggestionQuery = useQuery({
    queryKey: queryKeys.dashboard.suggestion(),
    queryFn: getDashboardSuggestion,
    enabled: !USE_MOCK_DASHBOARD,
    initialData: {
      title: dashboardData.suggestion.title,
      level: dashboardData.suggestion.level,
    },
  });

  const workspacesQuery = useQuery({
    queryKey: queryKeys.dashboard.workspaces(),
    queryFn: getWorkspaces,
    enabled: !USE_MOCK_DASHBOARD,
    initialData: dashboardData.workspaces,
  });

  const notificationsQuery = useQuery({
    queryKey: queryKeys.dashboard.notifications(),
    queryFn: getNotifications,
    enabled: !USE_MOCK_DASHBOARD,
    initialData: dashboardData.notifications,
  });

  const allQueries = [
    userQuery,
    learningPathQuery,
    coursesQuery,
    upcomingExamQuery,
    statsQuery,
    suggestionQuery,
    workspacesQuery,
    notificationsQuery,
  ];

  const activeWorkspaceId =
    workspacesQuery.data.find((workspace) => workspace.id === dashboardData.activeWorkspaceId)
      ?.id ?? workspacesQuery.data[0]?.id ?? dashboardData.activeWorkspaceId;

  return {
    data: {
      user: userQuery.data,
      sidebarItems: dashboardData.sidebarItems,
      learningPath: learningPathQuery.data,
      courses: mergeCoursesWithUiMeta(coursesQuery.data),
      upcomingExam: upcomingExamQuery.data,
      streakDays: statsQuery.data.streakDays,
      rankPoints: statsQuery.data.rankPoints,
      rankLabel: statsQuery.data.rankLabel,
      suggestion: mergeSuggestionWithUiMeta(suggestionQuery.data),
      workspaces: workspacesQuery.data as WorkspaceOption[],
      activeWorkspaceId,
      notifications: notificationsQuery.data as NotificationItem[],
    },
    isLoading: allQueries.some((query) => query.isLoading),
    isFetching: allQueries.some((query) => query.isFetching),
    hasAnyError: allQueries.some((query) => query.isError),
  };
}

export function useNotificationsQuery() {
  return useQuery({
    queryKey: queryKeys.dashboard.notifications(),
    queryFn: getNotifications,
  });
}

export function useMarkNotificationAsRead() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: markNotificationAsRead,
    onSuccess: () => {
      void queryClient.invalidateQueries({
        queryKey: queryKeys.dashboard.notifications(),
      });
    },
  });
}

export function useMarkAllNotificationsAsRead() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: markAllNotificationsAsRead,
    onSuccess: () => {
      void queryClient.invalidateQueries({
        queryKey: queryKeys.dashboard.notifications(),
      });
    },
  });
}
