import {
  BookOpen,
  ClipboardCheck,
  Container,
  FileText,
  LayoutDashboard,
  Route,
  ShieldCheck,
  TerminalSquare,
  UserRound,
} from "lucide-react";

import type {
  CourseCardItem,
  NotificationItem,
  DashboardSuggestion,
  DashboardUser,
  LearningPath,
  SidebarItem,
  UpcomingExam,
  WorkspaceOption,
} from "@/types";
import { routes } from "@/lib/config/routes";

interface DashboardData {
  user: DashboardUser;
  sidebarItems: SidebarItem[];
  learningPath: LearningPath;
  courses: CourseCardItem[];
  upcomingExam: UpcomingExam;
  streakDays: number;
  rankPoints: number;
  rankLabel: string;
  suggestion: DashboardSuggestion;
  workspaces: WorkspaceOption[];
  activeWorkspaceId: string;
  notifications: NotificationItem[];
}

export const dashboardData: DashboardData = {
  user: {
    name: "John Doe",
    email: "john@learnops.dev",
    role: "Learner",
    initials: "JD",
  },
  sidebarItems: [
    {
      label: "Dashboard",
      href: routes.dashboard,
      icon: LayoutDashboard,
    },
    {
      label: "Paths",
      href: routes.paths,
      icon: Route,
    },
    {
      label: "Courses",
      href: routes.courses,
      icon: BookOpen,
    },
    {
      label: "Exams",
      href: routes.exams,
      icon: ClipboardCheck,
    },
    {
      label: "Docs",
      href: routes.docs,
      icon: FileText,
    },
    {
      label: "Profile",
      href: routes.profile,
      icon: UserRound,
    },
  ],
  learningPath: {
    title: "DevOps Engineer Path",
    progress: 42,
    nextStep: "Kubernetes / Deployments",
  },
  courses: [
    {
      id: "linux-bash",
      title: "Introduction to Linux and Bash Scripting",
      description: "Temel shell komutları, script akışı ve otomasyon.",
      completedLessons: 8,
      totalLessons: 12,
      level: "Beginner",
      progress: 66,
      icon: TerminalSquare,
      progressTone: "emerald",
    },
    {
      id: "docker",
      title: "Docker for Beginners",
      description: "Container yaşam döngüsü, image yönetimi ve compose.",
      completedLessons: 4,
      totalLessons: 15,
      level: "Beginner",
      progress: 27,
      icon: Container,
      progressTone: "blue",
    },
    {
      id: "k8s-fundamentals",
      title: "Kubernetes Fundamentals",
      description: "Cluster bileşenleri, workload ve servis yaklaşımı.",
      completedLessons: 2,
      totalLessons: 14,
      level: "Intermediate",
      progress: 14,
      icon: ShieldCheck,
      progressTone: "indigo",
    },
  ],
  upcomingExam: {
    title: "Kubernetes Fundamentals",
    nextAttempt: "Today",
    readiness: 85,
    level: "Beginner",
  },
  streakDays: 3,
  rankPoints: 122,
  rankLabel: "Intermediate",
  suggestion: {
    title: "Docker Advance Techniques",
    level: "Intermediate",
    icon: Container,
  },
  workspaces: [
    {
      id: "learnops-core",
      name: "LearnOps Core",
      environment: "prod",
    },
    {
      id: "learnops-staging",
      name: "LearnOps Staging",
      environment: "staging",
    },
    {
      id: "learnops-dev",
      name: "LearnOps Dev",
      environment: "dev",
    },
  ],
  activeWorkspaceId: "learnops-core",
  notifications: [
    {
      id: "n-01",
      title: "Quiz window opened",
      message: "Kubernetes Fundamentals exam is now available.",
      timeLabel: "2m ago",
      read: false,
    },
    {
      id: "n-02",
      title: "Course updated",
      message: "Docker for Beginners has 2 new lessons.",
      timeLabel: "1h ago",
      read: false,
    },
    {
      id: "n-03",
      title: "Reminder",
      message: "You have an upcoming exam today.",
      timeLabel: "3h ago",
      read: true,
    },
  ],
};
