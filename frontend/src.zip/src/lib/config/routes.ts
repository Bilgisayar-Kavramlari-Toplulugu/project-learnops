export const routes = {
  root: "/",
  dashboard: "/dashboard",
  landing: "/landing",
  login: "/login",
  paths: "/paths",
  courses: "/courses",
  exams: "/exams",
  docs: "/docs",
  profile: "/profile",
} as const;

