export const queryKeys = {
  dashboard: {
    all: ["dashboard"] as const,
    user: () => [...queryKeys.dashboard.all, "user"] as const,
    learningPath: () => [...queryKeys.dashboard.all, "learning-path"] as const,
    courses: () => [...queryKeys.dashboard.all, "courses"] as const,
    upcomingExam: () => [...queryKeys.dashboard.all, "upcoming-exam"] as const,
    stats: () => [...queryKeys.dashboard.all, "stats"] as const,
    suggestion: () => [...queryKeys.dashboard.all, "suggestion"] as const,
    workspaces: () => [...queryKeys.dashboard.all, "workspaces"] as const,
    notifications: () => [...queryKeys.dashboard.all, "notifications"] as const,
  },
  auth: {
    all: ["auth"] as const,
    me: () => [...queryKeys.auth.all, "me"] as const,
  },
};
