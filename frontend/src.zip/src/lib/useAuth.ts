"use client";

import { useQueryClient } from "@tanstack/react-query";

import { queryKeys } from "@/lib/api/query-keys";
import {
  clearAccessToken,
  getAccessToken,
  setAccessToken,
} from "@/lib/auth/token-storage";

export function useAuth() {
  const queryClient = useQueryClient();
  const token = getAccessToken();

  async function loginWithToken(nextToken: string) {
    setAccessToken(nextToken);
    await queryClient.invalidateQueries({ queryKey: queryKeys.auth.all });
  }

  async function logout() {
    clearAccessToken();
    await queryClient.cancelQueries();
    queryClient.clear();
  }

  return {
    token,
    isAuthenticated: Boolean(token),
    loginWithToken,
    logout,
  };
}
