const ACCESS_TOKEN_KEY = "learnops-access-token";
const TOKEN_COOKIE_TTL_SECONDS = 60 * 60 * 24 * 7;

function readCookie(name: string) {
  if (typeof document === "undefined") {
    return null;
  }

  const encodedName = `${name}=`;
  const cookies = document.cookie.split(";");

  for (const cookie of cookies) {
    const normalizedCookie = cookie.trim();

    if (normalizedCookie.startsWith(encodedName)) {
      return decodeURIComponent(normalizedCookie.slice(encodedName.length));
    }
  }

  return null;
}

function writeTokenCookie(token: string) {
  if (typeof document === "undefined" || typeof window === "undefined") {
    return;
  }

  const secureFlag = window.location.protocol === "https:" ? "; Secure" : "";
  document.cookie = `${ACCESS_TOKEN_KEY}=${encodeURIComponent(token)}; Path=/; Max-Age=${TOKEN_COOKIE_TTL_SECONDS}; SameSite=Lax${secureFlag}`;
}

function clearTokenCookie() {
  if (typeof document === "undefined") {
    return;
  }

  document.cookie = `${ACCESS_TOKEN_KEY}=; Path=/; Max-Age=0; SameSite=Lax`;
}

export function getAccessToken() {
  if (typeof window === "undefined") {
    return null;
  }

  return localStorage.getItem(ACCESS_TOKEN_KEY) ?? readCookie(ACCESS_TOKEN_KEY);
}

export function setAccessToken(token: string) {
  if (typeof window === "undefined") {
    return;
  }

  localStorage.setItem(ACCESS_TOKEN_KEY, token);
  writeTokenCookie(token);
}

export function clearAccessToken() {
  if (typeof window === "undefined") {
    return;
  }

  localStorage.removeItem(ACCESS_TOKEN_KEY);
  clearTokenCookie();
}
