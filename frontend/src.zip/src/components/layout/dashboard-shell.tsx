import type { ReactNode } from "react";
import { Menu } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { routes } from "@/lib/config/routes";
import type {
  DashboardUser,
  NotificationItem,
  SidebarItem,
  WorkspaceOption,
} from "@/types";
import { AppSidebar } from "./app-sidebar";
import { AppTopbar } from "./app-topbar";

interface DashboardShellProps {
  user: DashboardUser;
  sidebarItems: SidebarItem[];
  workspaces: WorkspaceOption[];
  activeWorkspaceId: string;
  notifications: NotificationItem[];
  children: ReactNode;
}

export function DashboardShell({
  user,
  sidebarItems,
  workspaces,
  activeWorkspaceId,
  notifications,
  children,
}: DashboardShellProps) {
  return (
    <div className="min-h-screen">
      <div className="mx-auto flex min-h-screen w-full max-w-[1550px]">
        <aside className="hidden w-[292px] shrink-0 px-4 py-4 lg:block">
          <div className="sticky top-4">
            <AppSidebar items={sidebarItems} activePath={routes.dashboard} />
          </div>
        </aside>
        <div className="flex min-h-screen flex-1 flex-col gap-4 px-4 py-4 sm:px-6 lg:px-8">
          <AppTopbar
            user={user}
            workspaces={workspaces}
            activeWorkspaceId={activeWorkspaceId}
            notifications={notifications}
            mobileNav={
              <Sheet>
                <SheetTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    className="rounded-xl text-slate-600 hover:bg-blue-50 lg:hidden"
                  >
                    <Menu className="size-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent
                  side="left"
                  className="w-[292px] border-r border-slate-200 bg-white p-0 sm:max-w-none dark:border-slate-700 dark:bg-slate-900"
                >
                  <AppSidebar
                    items={sidebarItems}
                    activePath={routes.dashboard}
                    className="h-full rounded-none border-0 bg-transparent shadow-none"
                  />
                </SheetContent>
              </Sheet>
            }
          />
          <main className="flex-1">{children}</main>
        </div>
      </div>
    </div>
  );
}
