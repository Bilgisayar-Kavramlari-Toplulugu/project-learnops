import Link from "next/link";
import { HelpCircle, LogOut, Settings } from "lucide-react";

import { routes } from "@/lib/config/routes";
import { cn } from "@/lib/utils";
import type { SidebarItem } from "@/types";

interface AppSidebarProps {
  items: SidebarItem[];
  activePath: string;
  className?: string;
}

export function AppSidebar({ items, activePath, className }: AppSidebarProps) {
  return (
    <div
      className={cn(
        "flex max-h-[calc(100vh-2rem)] flex-col gap-6 overflow-y-auto rounded-3xl border border-slate-200/80 bg-white/80 p-4 shadow-sm shadow-slate-200/60 dark:border-slate-700/80 dark:bg-slate-900/82 dark:shadow-black/25",
        className,
      )}
    >
      <div className="space-y-6">
        <Link
          href={routes.dashboard}
          className="flex items-center justify-between gap-3 rounded-2xl border border-blue-100/80 bg-white/90 px-3 py-3 shadow-sm shadow-blue-100/40 dark:border-slate-700 dark:bg-slate-900/85 dark:shadow-black/20"
        >
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 text-base font-bold text-white shadow-sm">
              L
            </div>
            <div className="leading-none">
              <p className="text-lg font-semibold tracking-tight text-slate-900 dark:text-slate-100">
                LearnOps
              </p>
              <p className="mt-1 text-[11px] font-medium tracking-wide text-slate-500 uppercase dark:text-slate-400">
                Learning Platform
              </p>
            </div>
          </div>
          <span className="rounded-full border border-blue-100 bg-blue-50 px-2 py-0.5 text-[10px] font-semibold tracking-wide text-blue-700 uppercase dark:border-slate-700 dark:bg-slate-800 dark:text-sky-300">
            Beta
          </span>
        </Link>

        <div className="space-y-2">
          <p className="px-2 text-[11px] font-semibold tracking-[0.12em] text-slate-400 uppercase dark:text-slate-500">
            Main Navigation
          </p>
          <nav className="space-y-1.5">
            {items.map((item) => {
              const isActive = item.href === activePath;
              const Icon = item.icon;

              return (
                <Link
                  key={item.label}
                  href={item.href}
                  className={cn(
                    "group relative flex items-center gap-3 rounded-2xl border px-3 py-2.5 transition",
                    isActive
                      ? "border-blue-100 bg-white text-slate-900 shadow-sm shadow-blue-100/50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:shadow-black/20"
                      : "border-transparent text-slate-600 hover:border-blue-100/80 hover:bg-white/80 hover:text-slate-900 dark:text-slate-300 dark:hover:border-slate-700 dark:hover:bg-slate-900/75 dark:hover:text-slate-100",
                  )}
                >
                  {isActive ? (
                    <span className="absolute top-2 bottom-2 left-0 w-1 rounded-r-full bg-blue-600" />
                  ) : null}
                  <div
                    className={cn(
                      "flex size-9 items-center justify-center rounded-xl transition",
                      isActive
                        ? "bg-blue-600 text-white shadow-sm"
                        : "bg-blue-50 text-blue-700 group-hover:bg-blue-100 dark:bg-slate-800 dark:text-sky-300 dark:group-hover:bg-slate-700",
                    )}
                  >
                    <Icon className="size-[18px]" />
                  </div>
                  <span className="text-sm font-semibold tracking-tight">{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>
      </div>

      <div className="space-y-3 pt-1">
        <div className="rounded-2xl border border-blue-100/80 bg-white/85 p-3 shadow-sm shadow-blue-100/40 dark:border-slate-700 dark:bg-slate-900/80 dark:shadow-black/20">
          <p className="text-xs font-semibold tracking-wide text-slate-700 uppercase dark:text-slate-200">
            Need Help?
          </p>
          <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
            Dokumantasyon ve onboarding adimlari burada olacak.
          </p>
          <button
            type="button"
            className="mt-2 inline-flex items-center gap-2 rounded-xl border border-blue-100 bg-blue-50 px-2.5 py-1.5 text-xs font-semibold text-blue-700 transition hover:bg-blue-100 dark:border-slate-700 dark:bg-slate-800 dark:text-sky-300 dark:hover:bg-slate-700"
          >
            <HelpCircle className="size-3.5" />
            Open Guide
          </button>
        </div>

        <div className="space-y-1.5">
          <button
            type="button"
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-white/85 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-900/70 dark:hover:text-slate-100"
          >
            <Settings className="size-[18px]" />
            <span>Settings</span>
          </button>
          <button
            type="button"
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-white/85 hover:text-red-600 dark:text-slate-300 dark:hover:bg-slate-900/70 dark:hover:text-red-400"
          >
            <LogOut className="size-[18px]" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </div>
  );
}
