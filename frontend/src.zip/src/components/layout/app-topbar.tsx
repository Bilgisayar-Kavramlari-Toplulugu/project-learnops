"use client";

import type { ReactNode } from "react";
import { Bell, Check, ChevronDown, Dot } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import type {
  DashboardUser,
  NotificationItem,
  WorkspaceOption,
} from "@/types";
import { useUiStore } from "@/store/ui.store";
import {
  useMarkAllNotificationsAsRead,
  useMarkNotificationAsRead,
} from "@/features/dashboard/hooks/use-dashboard";
import { env } from "@/lib/config/env";
import { ThemeToggle } from "./theme-toggle";

interface AppTopbarProps {
  user: DashboardUser;
  workspaces: WorkspaceOption[];
  activeWorkspaceId: string;
  notifications: NotificationItem[];
  mobileNav?: ReactNode;
}

const envBadgeClasses: Record<WorkspaceOption["environment"], string> = {
  prod: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  staging: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  dev: "bg-sky-100 text-sky-700 dark:bg-sky-900/40 dark:text-sky-300",
};
const USE_MOCK_DASHBOARD = env.nextPublicUseMockDashboard;

export function AppTopbar({
  user,
  workspaces,
  activeWorkspaceId,
  notifications,
  mobileNav,
}: AppTopbarProps) {
  const selectedWorkspaceId =
    useUiStore((state) => state.selectedWorkspaceId) ?? activeWorkspaceId;
  const setSelectedWorkspaceId = useUiStore(
    (state) => state.setSelectedWorkspaceId,
  );
  const [items, setItems] = useState(notifications);
  const markNotificationAsReadMutation = useMarkNotificationAsRead();
  const markAllNotificationsAsReadMutation = useMarkAllNotificationsAsRead();

  useEffect(() => {
    setItems(notifications);
  }, [notifications]);

  const unreadCount = useMemo(
    () => items.filter((notification) => !notification.read).length,
    [items],
  );

  const selectedWorkspace =
    workspaces.find((workspace) => workspace.id === selectedWorkspaceId) ??
    workspaces[0];

  function markAllAsRead() {
    setItems((prev) => prev.map((item) => ({ ...item, read: true })));

    if (!USE_MOCK_DASHBOARD) {
      markAllNotificationsAsReadMutation.mutate();
    }
  }

  function markAsRead(notificationId: string) {
    setItems((prev) =>
      prev.map((item) =>
        item.id === notificationId ? { ...item, read: true } : item,
      ),
    );

    if (!USE_MOCK_DASHBOARD) {
      markNotificationAsReadMutation.mutate(notificationId);
    }
  }

  return (
    <header className="flex items-center justify-between gap-3 rounded-2xl border border-blue-100/80 bg-white/80 px-3 py-2.5 shadow-sm shadow-blue-100/40 backdrop-blur sm:px-4 dark:border-slate-700/80 dark:bg-slate-900/70 dark:shadow-black/20">
      <div className="flex items-center gap-2">
        <div className="lg:hidden">{mobileNav}</div>
        <p className="hidden text-xs font-medium tracking-wide text-slate-500 uppercase sm:block dark:text-slate-400">
          LearnOps Workspace
        </p>
      </div>
      <div className="flex items-center gap-2">
        <ThemeToggle />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon-sm"
              className="relative rounded-xl text-slate-500 hover:bg-blue-50 hover:text-blue-700 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-slate-100"
            >
              <Bell className="size-[18px]" />
              {unreadCount > 0 ? (
                <span className="absolute -top-1 -right-1 inline-flex min-w-5 items-center justify-center rounded-full bg-blue-600 px-1.5 text-[10px] font-semibold text-white dark:bg-sky-500 dark:text-slate-900">
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              ) : null}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-[340px] p-0">
            <div className="flex items-center justify-between border-b border-blue-100 px-3 py-2 dark:border-slate-700">
              <DropdownMenuLabel className="p-0 text-sm font-semibold">
                Notifications
              </DropdownMenuLabel>
              <button
                type="button"
                onClick={markAllAsRead}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 dark:text-sky-400 dark:hover:text-sky-300"
              >
                Mark all as read
              </button>
            </div>
            <div className="max-h-80 overflow-y-auto p-1.5">
              {items.map((notification) => (
                <DropdownMenuItem
                  key={notification.id}
                  onSelect={(event) => {
                    event.preventDefault();
                    markAsRead(notification.id);
                  }}
                  className={cn(
                    "mb-1 flex items-start gap-2 rounded-lg px-2.5 py-2",
                    notification.read
                      ? "text-slate-500 dark:text-slate-400"
                      : "text-slate-800 dark:text-slate-100",
                  )}
                >
                  <span className="pt-1">
                    {notification.read ? (
                      <Check className="size-3.5 text-emerald-500" />
                    ) : (
                      <Dot className="size-4 text-blue-600 dark:text-sky-400" />
                    )}
                  </span>
                  <span className="space-y-0.5">
                    <span className="block text-sm font-semibold">{notification.title}</span>
                    <span className="block text-xs leading-relaxed">
                      {notification.message}
                    </span>
                  </span>
                  <DropdownMenuShortcut className="mt-0.5 text-[10px]">
                    {notification.timeLabel}
                  </DropdownMenuShortcut>
                </DropdownMenuItem>
              ))}
            </div>
          </DropdownMenuContent>
        </DropdownMenu>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              className="hidden items-center gap-2 rounded-xl border border-blue-100 bg-white px-3 py-2 text-sm font-medium text-slate-600 sm:inline-flex dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
            >
              <span>{selectedWorkspace?.name ?? "Workspace"}</span>
              {selectedWorkspace ? (
                <span
                  className={cn(
                    "rounded-full px-1.5 py-0.5 text-[10px] font-semibold uppercase",
                    envBadgeClasses[selectedWorkspace.environment],
                  )}
                >
                  {selectedWorkspace.environment}
                </span>
              ) : null}
              <ChevronDown className="size-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Workspaces</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {workspaces.map((workspace) => (
              <DropdownMenuItem
                key={workspace.id}
                onSelect={() => setSelectedWorkspaceId(workspace.id)}
                className="justify-between"
              >
                <span>{workspace.name}</span>
                <span
                  className={cn(
                    "rounded-full px-1.5 py-0.5 text-[10px] font-semibold uppercase",
                    envBadgeClasses[workspace.environment],
                  )}
                >
                  {workspace.environment}
                </span>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              className="h-10 rounded-xl px-2 hover:bg-blue-50 dark:hover:bg-slate-800"
            >
              <Avatar className="size-8 border border-blue-100 dark:border-slate-700">
                <AvatarImage alt={user.name} />
                <AvatarFallback className="bg-blue-100 text-blue-800 dark:bg-slate-800 dark:text-slate-100">
                  {user.initials}
                </AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="space-y-0.5">
              <p className="font-semibold text-slate-900 dark:text-slate-100">{user.name}</p>
              <p className="text-xs font-normal text-slate-500 dark:text-slate-400">{user.email}</p>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem>Settings</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-red-600 focus:text-red-700">
              Sign Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
